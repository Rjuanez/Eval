var searchData=
[
  ['baja_5fusuario',['baja_usuario',['../class_cjt__curso.html#a7d41a4d58689e02f10093b56fce7947b',1,'Cjt_curso::baja_usuario()'],['../class_curso.html#a6c279cf46fc2df8e8f1c8ae93cdffec9',1,'Curso::baja_usuario()']]],
  ['buscar_5fnuevo_5fproblema',['buscar_nuevo_problema',['../class_cjt__sesion.html#a4aef15fb48b0465b864eaebeb3808cd0',1,'Cjt_sesion']]]
];
