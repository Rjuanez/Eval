var searchData=
[
  ['nuevo_5fproblema',['nuevo_problema',['../class_sesion.html#aee7122e6303e811527e894a0f2d08fea',1,'Sesion']]],
  ['num_5fcursos',['num_cursos',['../class_cjt__curso.html#a1ad84838189a13e86741d96cf2107d9c',1,'Cjt_curso']]],
  ['num_5finscritos',['num_inscritos',['../class_cjt__curso.html#ac160a24d24ca6a57b7e8bf6925b10343',1,'Cjt_curso::num_inscritos()'],['../class_curso.html#aca56beb776cf49d4c330e446032cd572',1,'Curso::num_inscritos()']]],
  ['num_5fproblemas',['num_problemas',['../class_cjt__problema.html#acf0fca6955f991a9debb4ef50ece8905',1,'Cjt_problema::num_problemas()'],['../class_sesion.html#a7778f2d0cfff81138221fe661ab69e2c',1,'Sesion::num_problemas()']]],
  ['num_5fproblemas_5fsesion',['num_problemas_sesion',['../class_cjt__sesion.html#ac761936095af984ee9a39fdcdf25219c',1,'Cjt_sesion']]],
  ['num_5fsesiones',['num_sesiones',['../class_cjt__curso.html#ad20fa025853fba4451e60e9b0cdb4011',1,'Cjt_curso::num_sesiones()'],['../class_cjt__sesion.html#aa885f9672e699d82dcd22aaa26d1ada8',1,'Cjt_sesion::num_sesiones()'],['../class_curso.html#a39e86aa0e422cbabb906fcb4878a1a86',1,'Curso::num_sesiones()']]],
  ['num_5fusuarios',['num_usuarios',['../class_cjt__usuario.html#a92ec4442d4a6e8d50f4eb36413ade07e',1,'Cjt_usuario']]]
];
