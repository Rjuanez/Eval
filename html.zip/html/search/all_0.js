var searchData=
[
  ['actualizar_5fenviables',['actualizar_enviables',['../class_usuario.html#a4dbe4aafe7c5308293ef5f6094f35bb1',1,'Usuario']]],
  ['anadir_5fcurso',['anadir_curso',['../class_cjt__curso.html#a8b79841cba9bb04c08a23e9dc376dd24',1,'Cjt_curso']]],
  ['anadir_5fproblema',['anadir_problema',['../class_cjt__problema.html#a6086147f5615c1cf42d6d563682b080d',1,'Cjt_problema']]],
  ['anadir_5fproblema_5fobjeto',['anadir_problema_objeto',['../class_cjt__problema.html#ada9dc37cd22fd8065c89ef3f180beac5',1,'Cjt_problema']]],
  ['anadir_5fsesion',['anadir_sesion',['../class_cjt__sesion.html#ace504b799e2c370749ccb16f9312fa5f',1,'Cjt_sesion']]],
  ['anadir_5fusuario',['anadir_usuario',['../class_cjt__usuario.html#a1a587cd6e8e3f261f27981134d0216e5',1,'Cjt_usuario']]]
];
