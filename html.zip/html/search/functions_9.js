var searchData=
[
  ['problema',['Problema',['../class_problema.html#a9d81af5f3f42a1b4354ad8f3c022fca3',1,'Problema::Problema()'],['../class_problema.html#ae114210c654baa6e728c412f7e64cb80',1,'Problema::Problema(string id)']]],
  ['problemas_5fenviables',['problemas_enviables',['../class_cjt__usuario.html#adf8f61c7eacd7328896c168adb3e63cd',1,'Cjt_usuario']]],
  ['problemas_5fresueltos',['problemas_resueltos',['../class_cjt__usuario.html#aa1cfea5c4294317758f260033f9fbd3f',1,'Cjt_usuario']]]
];
