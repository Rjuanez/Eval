var searchData=
[
  ['envios',['envios',['../class_problema.html#aaef8dcb723fa829a052517a00aed003e',1,'Problema::envios()'],['../class_usuario.html#a485a741c0646e6414bd6cf669a77fc9c',1,'Usuario::envios()']]],
  ['envios_5fexitosos',['envios_exitosos',['../class_problema.html#ad8f0dfd65c2673395ad72ae9817cb7ae',1,'Problema']]]
];
