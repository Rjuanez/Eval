var searchData=
[
  ['usuario',['Usuario',['../class_usuario.html#aa85a5371a098dfba5449140d9b8a472f',1,'Usuario::Usuario()'],['../class_usuario.html#adbc2bd125ed21ba9e091e3593e31f4cd',1,'Usuario::Usuario(std::string id)']]]
];
