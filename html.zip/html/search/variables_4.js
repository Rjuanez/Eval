var searchData=
[
  ['prerequisitos',['prerequisitos',['../class_sesion.html#abdfe53bdef12bfa9ab510cad99b0de27',1,'Sesion']]],
  ['problemas',['problemas',['../class_cjt__problema.html#a2d471986320805c5b27f8d14d486fca8',1,'Cjt_problema::problemas()'],['../class_sesion.html#af3929f5b3478c9ab1334b4c62566d69e',1,'Sesion::problemas()']]],
  ['problemas_5fenviables',['problemas_enviables',['../class_usuario.html#a553cef1aad192b30d010cd524f261c1b',1,'Usuario']]],
  ['problemas_5fintentados',['problemas_intentados',['../class_usuario.html#a5484a08ce9aeabef98074c738f58b00a',1,'Usuario']]],
  ['problemas_5fordenados',['problemas_ordenados',['../class_sesion.html#a4f770d029f7be9368a3abec6af7e8de7',1,'Sesion']]],
  ['problemas_5fresueltos',['problemas_resueltos',['../class_usuario.html#a53fa260ffc780dd5c3a4805d683e5ee7',1,'Usuario']]]
];
