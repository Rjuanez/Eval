var searchData=
[
  ['f_5fproblemas_5fenviables',['f_problemas_enviables',['../class_usuario.html#a11ee6d52132455ed32f3df6824c7b9c5',1,'Usuario']]],
  ['f_5fproblemas_5fresueltos',['f_problemas_resueltos',['../class_usuario.html#a6f504aa9a6cb6467e02a01b40951b31c',1,'Usuario']]]
];
