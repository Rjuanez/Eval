var searchData=
[
  ['sesion',['Sesion',['../class_sesion.html#adf5a84efa8e2629b30ad89df74cfc0a2',1,'Sesion::Sesion()'],['../class_sesion.html#a1b7a01575ed1e5a4d05765195dcfc189',1,'Sesion::Sesion(string id)']]],
  ['sumar_5fenvio',['sumar_envio',['../class_cjt__problema.html#a5450799b75298f2b267f3ecce7ba5fb0',1,'Cjt_problema::sumar_envio()'],['../class_problema.html#a418b7c394398c77cd81e5b8a1c218ba2',1,'Problema::sumar_envio()']]]
];
