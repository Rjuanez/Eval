var searchData=
[
  ['sesiones',['sesiones',['../class_cjt__sesion.html#abac1c2ee3cccc598a8274c7da869aa9b',1,'Cjt_sesion::sesiones()'],['../class_curso.html#a53e0e57eb6d683a83752082d633a03bc',1,'Curso::sesiones()']]]
];
